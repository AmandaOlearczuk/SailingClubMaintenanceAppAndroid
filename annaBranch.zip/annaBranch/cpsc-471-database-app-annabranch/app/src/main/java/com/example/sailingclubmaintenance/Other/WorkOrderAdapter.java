package com.example.sailingclubmaintenance.Other;
//@Credit: https://www.simplifiedcoding.net/android-recyclerview-cardview-tutorial/

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.sailingclubmaintenance.R;

import java.util.List;

/**
 * This class is used to add items to the work orders scrollable view.
 */
public class WorkOrderAdapter extends RecyclerView.Adapter<WorkOrderAdapter.WorkOrdersViewHolder> {


    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the work orders in a list
    private List<WorkOrder> workOrdersList;

    //getting the context and product list with constructor
    public WorkOrderAdapter(Context mCtx, List<WorkOrder> workOrders) {
        this.mCtx = mCtx;
        this.workOrdersList = workOrders;
    }

    @Override
    public WorkOrdersViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.one_work_order, null);
        return new WorkOrdersViewHolder(view);
    }

    @Override
    public void onBindViewHolder(WorkOrdersViewHolder holder, int position) {

        //getting the product of the specified position
        WorkOrder workOrder = workOrdersList.get(position);

        //binding the data with the viewholder views
        holder.textViewTask_number.setText(Integer.toString(workOrder.getTask_num()));
        holder.textViewTitle.setText(String.valueOf(workOrder.getTitle()));
        holder.textViewBoat_number.setText(workOrder.getBoat_num());
        holder.textViewClass.setText(String.valueOf(workOrder.getBoat_class()));

        StringBuilder sbProblems = new StringBuilder();

        if(workOrder.getProblem().size() != 0) {
            for (String s : workOrder.getProblem()) //can be empty.
            {
                sbProblems.append(s);
                sbProblems.append(",");
            }
        } else {
            sbProblems.append(" ");}

        holder.textViewProblem.setText(sbProblems.toString().substring(0, sbProblems.toString().length() - 1));

        StringBuilder sbParts = new StringBuilder();
        System.out.println("Problem parts: " + workOrder.getProblemParts().toString());
        for (String s : workOrder.getProblemParts()) //can't ever be empty
        {sbParts.append(s);sbParts.append(",");}//can't ever be empty

       holder.textViewPartslist.setText(sbParts.toString().substring(0,sbParts.toString().length() -1));//can't ever be empty

        holder.textViewDetails.setText(String.valueOf(workOrder.getDetails()));
        holder.textViewStatus.setText(String.valueOf(workOrder.getStatus()));
        if(workOrder.getStatus().equals("IN PROGRESS")){
            holder.textViewStatus.setBackgroundResource(R.color.orange);
        }
        else if(workOrder.getStatus().equals("COMPLETED")){
            holder.textViewStatus.setBackgroundResource(R.color.green);
        }

        holder.textViewWho_completed.setText(String.valueOf(workOrder.getFNCompleted()+" "+workOrder.getLNCompleted()));
        holder.textViewDate_completed.setText(String.valueOf(workOrder.getDateCompleted()));

        StringBuilder sbUsedParts= new StringBuilder();
        if(workOrder.getPartsUsed().size() != 0 ) {
            for (String s : workOrder.getPartsUsed()) {
                sbUsedParts.append(s);
                sbUsedParts.append(",");
            }
        } else {sbUsedParts.append(" ");}


        holder.textViewParts_used_list.setText(sbUsedParts.toString().substring(0,sbUsedParts.toString().length() -1));

        holder.textViewCreator.setText(String.valueOf(workOrder.getFNCreator()) + " " +workOrder.getLNCreator());
        holder.textViewWhen_created.setText(String.valueOf(workOrder.getDateCreated()));

        //holder.imageView.setImageDrawable(mCtx.getResources().getDrawable(workOrder.getImage()));

    }


    @Override
    public int getItemCount() {
        return workOrdersList.size();
    }


    /**
     * This class "holds" work order items - like text views, text boxes etc.
     */
    class WorkOrdersViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTask_number,textViewTitle, textViewBoat_number, textViewClass, textViewProblem, textViewPartslist
                , textViewDetails, textViewStatus,textViewWho_completed, textViewDate_completed,textViewParts_used_list,
                textViewCreator,textViewWhen_created;


        public WorkOrdersViewHolder(View itemView) {
            super(itemView);

            textViewTask_number = itemView.findViewById(R.id.TaskNum);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewBoat_number = itemView.findViewById(R.id.textViewBoatNum);
            textViewClass = itemView.findViewById(R.id.textViewBoatClass);
            textViewProblem = itemView.findViewById(R.id.textViewProblems);
            textViewPartslist = itemView.findViewById(R.id.textProblemsWith);
            textViewDetails=itemView.findViewById(R.id.textViewDetailsText);
            textViewStatus=itemView.findViewById(R.id.textViewStatus);
            textViewWho_completed = itemView.findViewById(R.id.textViewCompletedBy);
            textViewDate_completed = itemView.findViewById(R.id.textViewDateCompleted);
            textViewParts_used_list=itemView.findViewById(R.id.textViewPartsUsed);
            textViewCreator = itemView.findViewById(R.id.WhoCreated);
            textViewWhen_created=itemView.findViewById(R.id.dateCreated);

        }
    }
}
