package com.example.sailingclubmaintenance.Database;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;

import com.example.sailingclubmaintenance.appactivities.WorkOrdersActivity;
import com.example.sailingclubmaintenance.login.Globals;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DatabaseWorkOrderFetching extends AsyncTask<String, Void, Map> {

    private Context context;

    public static Map<String, HashMap<String, ArrayList<String>>> resultMap = new HashMap<>();

    //Constructor
    public DatabaseWorkOrderFetching(Context ctx) {
        context = ctx;
    }

    @Override
    protected Map doInBackground(String... params) {

        try {
            resultMap = new HashMap<>();

            String yourIpV4 = Globals.yourIPV4;
            String taskJOINcreates = "task_join_creates.php";
            String taskJOINproblem = "task_join_problem.php";
            String taskJOINrelates_to = "task_join_relates_to.php";
            String taskJOINissue = "task_join_issue.php";
            String taskJOINused = "task_join_used.php";
            String taskJOINcomplete = "task_join_complete.php";

            JSONArray jsonArray1 = retrieveData(yourIpV4,taskJOINcreates);
            JSONArray jsonArray2 = retrieveData(yourIpV4,taskJOINproblem);
            JSONArray jsonArray3 = retrieveData(yourIpV4,taskJOINrelates_to);
            JSONArray jsonArray4 = retrieveData(yourIpV4,taskJOINissue);
            JSONArray jsonArray5 = retrieveData(yourIpV4,taskJOINused);
            JSONArray jsonArray6 = retrieveData(yourIpV4,taskJOINcomplete);

             //Loop through task_join_creates, also creating resultMap template.
            for (int i = 0; i < jsonArray1.length(); i++) {
                JSONObject jo = (JSONObject) jsonArray1.get(i);
                ArrayList<String> oneObject = new ArrayList<String>();

                String currentWorkOrderNum = (String) String.valueOf((Integer)jo.get("task_number"));

                if (resultMap.containsKey(currentWorkOrderNum)) { //Check if map already has an entry for this work order
                    HashMap<String, ArrayList<String>> currentDictionary = resultMap.get(currentWorkOrderNum); //Retrieve that work order
                    for (String key : currentDictionary.keySet()) {
                        ArrayList<String> values = currentDictionary.get(key);
                        values.add((String) jo.get(key));
                    }
                } else { //Initialize work order entry in a dictionary for that work order
                    HashMap<String, ArrayList<String>> hm = new HashMap<>();
                    hm.put("Title", new ArrayList<String>());
                    hm.put("Details", new ArrayList<String>());
                    hm.put("FirstName", new ArrayList<String>()); //first name of person who created
                    hm.put("LastName", new ArrayList<String>()); //second name of person who created
                    hm.put("dateCreated", new ArrayList<String>());

                    hm.put("SerialNum", new ArrayList<String>()); //Of boat that relates to this task
                    hm.put("Class", new ArrayList<String>());

                    hm.put("completeFN", new ArrayList<String>()); //first name of person who completed
                    hm.put("completeLN", new ArrayList<String>()); //second name of person who completed

                    hm.put("problem", new ArrayList<String>()); //Select out of 4 or none at all
                    hm.put("issue", new ArrayList<String>());
                    hm.put("dateCompleted", new ArrayList<String>());
                    hm.put("partNum", new ArrayList<String>());

                    resultMap.put(currentWorkOrderNum, hm);

                    HashMap<String, ArrayList<String>> currentDictionary = resultMap.get(currentWorkOrderNum); //Retrieve that work order
                    for (String key : currentDictionary.keySet()) {
                        ArrayList<String> values = currentDictionary.get(key);
                        try{values.add((String) jo.get(key));}catch (JSONException e){continue;}
                    }
                }


            }
            iterate(jsonArray2);
            iterate(jsonArray3);
            iterate(jsonArray4);
            iterate(jsonArray5);
            iterate(jsonArray6);


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return resultMap;
    }


        /**
     * What to do with the data once we get it..
     * @param result_map
     */
    @Override
    protected void onPostExecute(Map result_map) {
        Globals.tempWorkOrdersResult = result_map;
        ((Activity) context).finish();
        openActivityWorkOrders();
    }

    public void openActivityWorkOrders(){
        Intent intent = new Intent(context, WorkOrdersActivity.class); //context is screen that we called this method from (login screen)
        context.startActivity(intent);
        //((Activity)context).finish(); //kill the login activity

    }

    /**
     * This method retrieves data as JSON array from url.
     * @param yourIPV4
     * @param phpFileName
     * @return JSONArray
     * @throws IOException
     * @throws JSONException
     */
    public JSONArray retrieveData(String yourIPV4,String phpFileName) throws IOException, JSONException {
        String taskdata = "";

        //1.Create connection with url
        URL url = new URL("http://" + yourIPV4 + "/" + phpFileName);
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

        //2.Open channel of communication
        InputStream inputStream = httpURLConnection.getInputStream();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

        //3.Read line by line to get a string of data
        String line = "";
        while (line != null) {
            line = bufferedReader.readLine();
            taskdata = taskdata + line;
        }

        //4.Parse results, adding strings of data to ArrayList of ArrayLists
        JSONArray jsonArray = new JSONArray(taskdata);

        return jsonArray;
    }


    /**
     * This method iterates over json array of results, adding them to the hashmap dictionary
     * @param ja - JSONarray
     * @throws JSONException
     */
    public void iterate(JSONArray ja) throws JSONException {
        for (int i = 0; i < ja.length(); i++) {
            JSONObject jo = (JSONObject) ja.get(i);
            ArrayList<String> oneObject = new ArrayList<String>();

            String currentWorkOrderNum = String.valueOf(jo.get("task_number"));
            HashMap<String, ArrayList<String>> currentDictionary = resultMap.get(currentWorkOrderNum); //Retrieve that work order
            for (String key : currentDictionary.keySet()) {
                ArrayList<String> values = currentDictionary.get(key);
                try{values.add((String) jo.get(key));}catch(JSONException e){continue;}
            }
        }
    }
}
