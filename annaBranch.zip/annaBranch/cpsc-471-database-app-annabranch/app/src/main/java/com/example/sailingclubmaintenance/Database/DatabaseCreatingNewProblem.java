package com.example.sailingclubmaintenance.Database;

import android.content.Context;
import android.os.AsyncTask;

import com.example.sailingclubmaintenance.login.Globals;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * This class deals with retrieving login information from the database.
 * If it's successful, main menu will be opened.
 */
public class DatabaseCreatingNewProblem extends AsyncTask<String,Void,String> {

    private Context context;


    //Constructor
    public DatabaseCreatingNewProblem(Context ctx) {
        context = ctx;
    }

    @Override
    protected String doInBackground(String... params) {

        String yourIPV4 = Globals.yourIPV4;
        String create_task_url = "http://"+ yourIPV4 +"/create_problem.php";

        try {
            String task_number = params[0];
            String problem = params[1];
            URL url = new URL(create_task_url); //set url to which we will post this info
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST"); //make sure we are posting
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
            //Write the following data..
            String post_data = URLEncoder.encode("task_number","UTF-8")+"="+URLEncoder.encode(task_number,"UTF-8")
                    +"&"+URLEncoder.encode("problem","UTF-8")+"="+URLEncoder.encode(problem,"UTF-8");
            bufferedWriter.write(post_data);
            //Flush and close everything
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStream.close();

            //Now, we would like to recieve the result
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
            String result = "";
            String line;
            while((line = bufferedReader.readLine()) !=null){ //reading the result line by line
                result+=line;
            }
            //Log.d("myTag",result);
            bufferedReader.close();
            inputStream.close();
            httpURLConnection.disconnect();
            return result;


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



        return null;
    }

    @Override //This executes before we even start querying
    protected void onPreExecute() {

    }

    @Override //This executes after we recieved response from server - result is the response
    protected void onPostExecute(String result) {
        System.out.println("Reply : " + result);
        System.out.println("Creating new problem finished.");
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }


}


