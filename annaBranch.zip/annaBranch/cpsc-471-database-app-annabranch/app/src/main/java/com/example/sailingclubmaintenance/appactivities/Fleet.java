package com.example.sailingclubmaintenance.appactivities;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sailingclubmaintenance.R;
import com.example.sailingclubmaintenance.fleetexpandable.Boat;
import com.example.sailingclubmaintenance.fleetexpandable.BoatAdapter;
import com.example.sailingclubmaintenance.fleetexpandable.BoatType;
import com.example.sailingclubmaintenance.login.Globals;

import java.util.ArrayList;
import java.util.List;

public class Fleet extends AppCompatActivity {
    private boolean editableFlag;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fleet);

        editableFlag = false;
        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        BoatAdapter adapter = new BoatAdapter(Globals.sortedBoats);
        recyclerView.setAdapter(adapter);
    }

    private void startEditing(View view) {
        editableFlag = true;
    }

    private void stopEditing(View view) {
        editableFlag = false;
    }


    private ArrayList<BoatType> sortBoats(ArrayList<Boat> boatDB) {
        ArrayList<BoatType> sortedTypes = new ArrayList<>();
        for (int i = 0; i < boatDB.size(); i++) {
            Boat temp = boatDB.get(i);
            boolean typeExists = false;
            for(int j = 0; j < sortedTypes.size(); j++) {
                BoatType boatType = sortedTypes.get(j);
                if(boatType.getTypeName().equals(temp.getBoatType())){
                    boatType.addMember(temp,true);
                    typeExists = true;
                }
            }
            if (!typeExists) {
                ArrayList<Boat> toAdd = new ArrayList<>();
                toAdd.add(temp);
                sortedTypes.add(new BoatType(temp.getBoatType(),toAdd));
            }
        }
        return sortedTypes;
    }

    protected ArrayList<Boat> readOutput(String result) {
        String[] temp = result.split(",");
        ArrayList<Boat> allBoats = new ArrayList<>();

        for(int i = 0; i<temp.length; i=i+8) {
            int serial = Integer.parseInt(temp[i].substring(temp[i].indexOf(":")+2,temp[i].length()-1));
            String name = temp[i+1].substring(temp[i+1].indexOf(":")+2,temp[i+1].length()-1);
            String boatType = temp[i+2].substring(temp[i+2].indexOf(":")+2,temp[i+2].length()-1);
            int year = Integer.parseInt(temp[i+3].substring(temp[i+3].indexOf(":")+1));
            String status = temp[i+4].substring(temp[i+4].indexOf(":")+2,temp[i+4].length()-1);
            String dateAdded  = temp[i+5].substring(temp[i+5].indexOf(":")+2,temp[i+5].length()-1);
            String loc = temp[i+6].substring(temp[i+6].indexOf(":")+2,temp[i+6].length()-1);
            int hull = Integer.parseInt(temp[i+7].substring(temp[i+7].indexOf(":")+1,temp[i+7].indexOf("}")));
            Boat boat = new Boat(serial,hull,name,status,year,dateAdded,boatType,loc);
            allBoats.add(boat);
        }
        return allBoats;
    }

    public void setRecyclerView(ArrayList<BoatType> boatTypes) {
        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        BoatAdapter adapter = new BoatAdapter(boatTypes);
        recyclerView.setAdapter(adapter);
    }
}

