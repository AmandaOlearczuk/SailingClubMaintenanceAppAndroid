package com.example.sailingclubmaintenance.appactivities;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;

import com.example.sailingclubmaintenance.fleetexpandable.Boat;
import com.example.sailingclubmaintenance.fleetexpandable.BoatType;
import com.example.sailingclubmaintenance.login.Globals;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;


public class FleetConnection extends AsyncTask<String,Void,String> {
    Context context;

    FleetConnection(Context c){
        context = c;
    }

    @Override
    protected String doInBackground(String... params) {
        String type = params[0];
        String login_url = "http://"+ Globals.yourIPV4+"/fleet_get.php";
        if(type.equals("datainit")) {
            try {
                URL url = new URL(login_url); //set url to which we will post this info
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST"); //make sure we are posting
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);

                //Now, we would like to recieve the result
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result = "";
                String line;
                while((line = bufferedReader.readLine()) !=null){ //reading the result line by line
                    result+=line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
    private ArrayList<BoatType> sortBoats(ArrayList<Boat> boatDB) {
        ArrayList<BoatType> sortedTypes = new ArrayList<>();
        for (int i = 0; i < boatDB.size(); i++) {
            Boat temp = boatDB.get(i);
            boolean typeExists = false;
            for(int j = 0; j < sortedTypes.size(); j++) {
                BoatType boatType = sortedTypes.get(j);
                if(boatType.getTypeName().equals(temp.getBoatType())){
                    boatType.addMember(temp,true);
                    typeExists = true;
                }
            }
            if (!typeExists) {
                ArrayList<Boat> toAdd = new ArrayList<>();
                toAdd.add(temp);
                sortedTypes.add(new BoatType(temp.getBoatType(),toAdd));
            }
        }
        return sortedTypes;
    }

    protected ArrayList<Boat> readOutput(String result) {
        String[] temp = result.split(",");
        ArrayList<Boat> allBoats = new ArrayList<>();

        for(int i = 0; i<temp.length; i=i+8) {
            int serial = Integer.parseInt(temp[i].substring(temp[i].indexOf(":")+2,temp[i].length()-1));
            String name = temp[i+1].substring(temp[i+1].indexOf(":")+2,temp[i+1].length()-1);
            String boatType = temp[i+2].substring(temp[i+2].indexOf(":")+2,temp[i+2].length()-1);
            int year = Integer.parseInt(temp[i+3].substring(temp[i+3].indexOf(":")+1));
            String status = temp[i+4].substring(temp[i+4].indexOf(":")+2,temp[i+4].length()-1);
            String dateAdded  = temp[i+5].substring(temp[i+5].indexOf(":")+2,temp[i+5].length()-1);
            String loc = temp[i+6].substring(temp[i+6].indexOf(":")+2,temp[i+6].length()-1);
            int hull = Integer.parseInt(temp[i+7].substring(temp[i+7].indexOf(":")+1,temp[i+7].indexOf("}")));
            Boat boat = new Boat(serial,hull,name,status,year,dateAdded,boatType,loc);
            allBoats.add(boat);
        }
        return allBoats;
    }
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String result) {
        ArrayList<Boat> allBoats = readOutput(result);
        ArrayList<BoatType> boatTypes = sortBoats(allBoats);
        Globals.sortedBoats = boatTypes;
        openActivityFleet();
    }
    public void openActivityFleet(){
        Intent intent = new Intent(context, Fleet.class);
        context.startActivity(intent);
    }


    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

}
