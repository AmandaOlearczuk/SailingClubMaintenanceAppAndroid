package com.example.sailingclubmaintenance.Notes;

public class Note {
    private int noteID;
    private String SSN;
    private String title;
    private String content;
    private String date;

    public Note(int noteID, String SSN, String title, String content){
        this.noteID = noteID;
        this.SSN = SSN;
        this.title = title;
        this.content = content;
        this.date = NewNote.currentDate;
    }

    public int getNoteID(){
        return noteID;
    }

    public String getTitle(){
        return title;
    }

    public String getContent(){
        return content;
    }

    public String getDate(){
        return date;
    }



}
