package com.example.sailingclubmaintenance.fleetexpandable;

import android.os.Parcel;
import android.os.Parcelable;

public class Boat implements Parcelable,Comparable<Boat> {
    private final int serialNum;
    private int hullNumber;
    private String name;
    private String status = null;
    private int year = -1;
    private String dateAdded = null;
    private String boatType = null;
    private String location = null;

    public Boat(int newID, int newHullNumber, String newName, String newStatus, int newYear, String newDateAdded, String newBoatType, String newLoc) {
        serialNum = newID;
        hullNumber = newHullNumber;
        name = newName;
        status = newStatus;
        year = newYear;
        dateAdded = newDateAdded;
        boatType = newBoatType;
        location = newLoc;
    }

    protected Boat(Parcel in) {
        serialNum = in.readInt();
        hullNumber = in.readInt();
        name = in.readString();
        status = in.readString();
        dateAdded = in.readString();
        boatType = in.readString();
    }

    public static final Creator<Boat> CREATOR = new Creator<Boat>() {
        @Override
        public Boat createFromParcel(Parcel in) {
            return new Boat(in);
        }

        @Override
        public Boat[] newArray(int size) {
            return new Boat[size];
        }
    };

    // Getter methods
    public int getSerialNum() {
        return serialNum;
    }
    public int getHullNumber() { return hullNumber; }
    public String getName() { return name; }
    public String getBoatType() { return boatType; }
    public String getStatus() { return status; }
    public String getDateAdded() {return dateAdded; }
    public String getLocation() {return location; }
    public int getYear() {return year; }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(Integer.toString(serialNum));
    }

    @Override
    public int compareTo(Boat boat) {
        if (this.hullNumber < boat.getHullNumber()) {
            return -1;
        }
        else {
            return 1;
        }
    }
}
