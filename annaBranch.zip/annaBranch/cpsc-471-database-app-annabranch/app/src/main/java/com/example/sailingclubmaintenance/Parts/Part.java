package com.example.sailingclubmaintenance.Parts;

public class Part {

    private String serialNum;
    private String type;
    private String condition;
    private String manDateMonth;
    private String manDateYear;
    private String purDate;
    private String manDate;
    private String stockName;

    public Part(String serialNum, String type, String condition, String manDateMonth, String manDateYear, String purDate, String stockName){
        this.serialNum = serialNum;
        this.condition = condition;
        this.type = type;
        this.manDateMonth = manDateMonth;
        this.manDateYear = manDateYear;
        this.purDate = purDate;
        this.stockName = stockName;

    }


    public String getSerialNum(){
        return serialNum;
    }
    public String getType(){
        return type;
    }
    public String getCondition(){
        return condition;
    }

    public String getManDateMonth(){
        return manDateMonth;
    }

    public String getManDateYear(){
        return manDateYear;
    }

    public String getManDate(){
        manDate = getManDateMonth()+"/"+getManDateYear();
        return manDate;
    }

    public String getPurDate(){
        return purDate;
    }

    public String getStockName(){
        return stockName;
    }




}
