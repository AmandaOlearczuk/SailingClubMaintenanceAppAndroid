package com.example.sailingclubmaintenance.fleetexpandable;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.sailingclubmaintenance.R;
import com.thoughtbot.expandablerecyclerview.ExpandableRecyclerViewAdapter;
import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup;

import java.util.List;

public class BoatAdapter extends ExpandableRecyclerViewAdapter<BoatTypeViewHolder, BoatViewHolder> {
    public BoatAdapter(List<? extends ExpandableGroup> groups) {
        super(groups);
    }

    @Override
    public BoatTypeViewHolder onCreateGroupViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.expandable_recyclerview_boat_type, parent, false);
        return new BoatTypeViewHolder(v);
    }

    @Override
    public BoatViewHolder onCreateChildViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.expandable_recyclerview_boat, parent, false);
        return new BoatViewHolder(v);
    }

    @Override
    public void onBindChildViewHolder(BoatViewHolder holder, int flatPosition, ExpandableGroup group, int childIndex) {
        final Boat boat = (Boat) group.getItems().get(childIndex);
        holder.bind(boat);
    }

    @Override
    public void onBindGroupViewHolder(BoatTypeViewHolder holder, int flatPosition, ExpandableGroup group) {
        final BoatType boatType = (BoatType) group;
        holder.bind(boatType);
    }
}
