package com.example.sailingclubmaintenance.Notes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.sailingclubmaintenance.R;
import com.example.sailingclubmaintenance.appactivities.ToDoActivity;
import com.example.sailingclubmaintenance.login.Globals;

import java.text.DateFormat;
import java.util.Calendar;


public class NewNote extends AppCompatActivity {

    EditText noteTitle, noteContent;
    public static String currentDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_note);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        noteTitle = findViewById(R.id.editTitle);
        noteContent = findViewById(R.id.editNote);

        //get current date to attach to note
        Calendar calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance(DateFormat.SHORT).format(calendar.getTime());

        TextView textViewDate = findViewById(R.id.date_created);
        textViewDate.setText(currentDate);

    }


    public void onSaveNote(View view) {

            String str_ssn = Globals.currentSSN; //get SSN of current user
            String str_noteTitle = noteTitle.getText().toString(); //get note title
            String str_noteContent = noteContent.getText().toString(); //get note content
            String type = "saveNewNote";

            DatabaseNoteTable dbNote = new DatabaseNoteTable(this);
            dbNote.execute(type, str_ssn, str_noteTitle, str_noteContent);



    }

    public void onDeleteNote(View view) {
        String str_ssn = Globals.currentSSN; //get SSN of current user
        String str_noteTitle = noteTitle.getText().toString(); //get note title
        String str_noteContent = noteContent.getText().toString(); //get note content
        String type = "deleteNote";

        DatabaseNoteTable dbNote = new DatabaseNoteTable(this);
        dbNote.execute(type, str_ssn, str_noteTitle, str_noteContent);

        //Return to notes menu
        Intent intent = new Intent(getApplicationContext(), ToDoActivity.class);
        startActivity(intent);

    }

}
