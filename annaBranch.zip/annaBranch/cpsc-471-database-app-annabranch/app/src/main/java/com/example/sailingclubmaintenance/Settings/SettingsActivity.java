package com.example.sailingclubmaintenance.Settings;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.sailingclubmaintenance.R;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        //Toolbar toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

    }

    public void changePassword(View view){
        Intent intent = new Intent(getApplicationContext(), ChangePassword.class);
        startActivity(intent);

    }

    public void addNewUser(View view) {
        Intent intent = new Intent(getApplicationContext(), AddNewUser.class);
        startActivity(intent);

    }

    public void removeUser(View view) {
        Intent intent = new Intent(getApplicationContext(), RemoveUser.class);
        startActivity(intent);

    }
}
