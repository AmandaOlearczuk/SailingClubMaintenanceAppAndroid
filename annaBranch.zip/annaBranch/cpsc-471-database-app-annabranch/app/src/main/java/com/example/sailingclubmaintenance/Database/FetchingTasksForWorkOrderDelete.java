package com.example.sailingclubmaintenance.Database;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.sailingclubmaintenance.login.Globals;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * This class is used to populate the spinner in new work order form
 */
public class FetchingTasksForWorkOrderDelete extends AsyncTask<Spinner, Void, ArrayList<String>> {

    private Context context;
    private ArrayList<String> taskNumbers = new ArrayList<String>();
    private Spinner spinner;

    //Constructor
    public FetchingTasksForWorkOrderDelete(Context ctx) {
        context = ctx;
    }

    @Override
    protected ArrayList<String> doInBackground(Spinner... params) { //Spinner is the argument we give
        spinner = params[0]; //Which is spinner
        String yourIpV4 = Globals.yourIPV4;
        String all_task_table = "get_all_tasks.php";

        try {
            JSONArray jsonArray1 = retrieveData(yourIpV4, all_task_table);

            //Loop to populate the boatANDName_Map map.
            for (int i = 0; i < jsonArray1.length(); i++) {
                JSONObject jo = (JSONObject) jsonArray1.get(i);
                taskNumbers.add(String.valueOf(jo.get("task_number")));
            }

        }catch(Exception e){e.printStackTrace();}

        return taskNumbers;
    }


    /**
     * What to do with the data once we get it..
     * @param taskNumbers
     */
    @Override
    protected void onPostExecute(ArrayList<String> taskNumbers) {

        //Here we are basically adding boats to the spinner
        ArrayList<String> tasks = taskNumbers;

        String[] tasks_converted = tasks.toArray(new String[tasks.size()]);

        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                context, android.R.layout.simple_spinner_item, tasks_converted);
        spinnerArrayAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );

        spinner.setAdapter(spinnerArrayAdapter);

    }


    /**
     * This method retrieves data as JSON array from url.
     * @param yourIPV4
     * @param phpFileName
     * @return JSONArray
     * @throws IOException
     * @throws JSONException
     */
    public JSONArray retrieveData(String yourIPV4,String phpFileName) throws IOException, JSONException {
        String taskdata = "";

        //1.Create connection with url
        URL url = new URL("http://" + yourIPV4 + "/" + phpFileName);
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

        //2.Open channel of communication
        InputStream inputStream = httpURLConnection.getInputStream();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

        //3.Read line by line to get a string of data
        String line = "";
        while (line != null) {
            line = bufferedReader.readLine();
            taskdata = taskdata + line;
        }

        //4.Parse results, adding strings of data to ArrayList of ArrayLists
        JSONArray jsonArray = new JSONArray(taskdata);

        return jsonArray;
    }


}
