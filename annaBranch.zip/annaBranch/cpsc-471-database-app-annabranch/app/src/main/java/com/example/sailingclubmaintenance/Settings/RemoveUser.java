package com.example.sailingclubmaintenance.Settings;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.sailingclubmaintenance.R;

public class RemoveUser extends AppCompatActivity {

    EditText ssn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_user);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ssn = (EditText)findViewById(R.id.userSSN);

    }

    public void deleteBtn(View view) {
        String str_ssn = ssn.getText().toString();

        String type = "removeUser";

        DatabaseAddRemoveUser dbUser = new DatabaseAddRemoveUser(this);
        dbUser.execute(type, str_ssn);

    }
}
