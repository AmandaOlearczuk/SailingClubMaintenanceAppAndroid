package com.example.sailingclubmaintenance.Other;

import java.util.ArrayList;
import java.util.LinkedHashSet;

public class WorkOrder {

    private int task_num = 0;
    private String title;
    private String boat_num = "";
    private String boat_class = "";
    private ArrayList<String> problem;
    private ArrayList<String> problemParts;
    private String details;
    private String status;
    private String completedFN = "";
    private String completedLN = "" ;
    private String dateCompleted = "";
    private ArrayList<String> partsUsed;
    private String createFN;
    private String createLN;
    private String dateCreated;



    public WorkOrder(int tasknum, String t, String boatnum, String boatclass, ArrayList<String> prob, ArrayList<String> problemparts
            , String det, String status_, String firstNameCompleter, String lastNameCompleter, String dateComp, ArrayList<String> partsused, String createFirstN,
                     String createLastN, String dateCreat) {
        this.title=t;
        this.task_num = tasknum;
        this.boat_num = boatnum;
        this.boat_class = boatclass;

        this.problem = prob;
        if(this.problem.size() != 0) { //remove duplicates
            System.out.println("problem.size() isn't empty");
            LinkedHashSet<String> hashSet = new LinkedHashSet<>(prob);
            ArrayList<String> listWithoutDuplicates = new ArrayList<>(hashSet);
            this.problem = listWithoutDuplicates;
        }

        LinkedHashSet<String> hashSet2 = new LinkedHashSet<>(problemparts); //issue table - can't ever be empty
        ArrayList<String> listWithoutDuplicates2 = new ArrayList<>(hashSet2);
        this.problemParts = listWithoutDuplicates2;

        this.details = det;
        this.status=status_;

        this.completedFN =firstNameCompleter;
        this.completedLN =lastNameCompleter;
        this.dateCompleted=dateComp;

        this.createFN=createFirstN;
        this.createLN=createLastN;
        this.dateCreated =dateCreat;

        this.partsUsed = partsused;
        if(this.partsUsed.size() != 0){ //remove duplicates
            LinkedHashSet<String> hashSet3 = new LinkedHashSet<>(partsused);
            ArrayList<String> listWithoutDuplicates3 = new ArrayList<>(hashSet3);
            this.partsUsed=listWithoutDuplicates3;
        }

    }


    public int getTask_num() {
        return task_num;
    }

    public String getTitle() {
        return title;
    }

    public String getStatus() {
        return status;
    }

    public String getBoat_num() {
        return boat_num;
    }

    public String getBoat_class() {
        return boat_class;
    }

    public ArrayList<String> getProblem() {
        return problem;
    }

    public ArrayList<String> getProblemParts() {
        return problemParts;
    }

    public String getDetails() {
        return details;
    }

    public String getFNCompleted() {
        return completedFN;
    }

    public String getLNCompleted() {
        return completedLN;
    }

    public String getDateCompleted() {
        return dateCompleted;
    }

    public ArrayList<String> getPartsUsed() {
        return partsUsed;
    }

    public String getFNCreator() {
        return createFN;
    }

    public String getLNCreator() {
        return createLN;
    }


    public String getDateCreated() {
        return dateCreated;
    }
}
