<?php
require "connection.php";

$sql = $connection->prepare('select noteID, SSN, title, content from note');
$sql->execute();

if ($result = $sql->get_result())
{
 $resultArray = array();
 $tempArray = array();
 
 while($row = $result->fetch_object())
 {
 $tempArray = $row;
 $resultArray[] = $tempArray;
 }
 
 // Encode the array to JSON and output the results
 echo json_encode($resultArray);
}

?>