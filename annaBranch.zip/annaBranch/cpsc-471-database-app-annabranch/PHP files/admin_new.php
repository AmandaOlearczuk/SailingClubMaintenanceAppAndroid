<?php

require "connection.php";

$SSN = $_POST["SSN"];

$mysql_qry = "insert into admin (SSN) values ('$SSN')";

if($connection->query($mysql_qry)===TRUE){
echo "Admin added";
}
else{
echo "Error: " . $mysql_qry . "<br>" . $connection->error;
}
 
$connection->close();

?>