<?php
require "connection.php";

$task_number = $_POST["task_number"];

//Preventing sql injection..
$statement1 = $connection->prepare('delete from task where task_number = ?');
$statement1->bind_param('s',$task_number);
$result1 = $statement1->execute();

if($result1){
	echo "Success";
}else{echo "Not successful";}
?>