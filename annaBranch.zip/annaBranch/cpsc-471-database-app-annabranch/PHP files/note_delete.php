<?php

require "connection.php";

$SSN = $_POST["ssn"];
$title = $_POST["title"];
$content = $_POST["content"];

$mysql_qry = "delete from note where SSN = '$SSN' and title = '$title' and content = '$content'';


if($connection->query($mysql_qry)===TRUE){
echo "Note deleted";
}
else{
echo "Error: " . $mysql_qry . "<br>" . $connection->error;
}
 
$connection->close();

?>