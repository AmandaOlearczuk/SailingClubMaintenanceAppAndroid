<?php
require "connection.php";

$sql2 = $connection->prepare('select task.task_number,problem.problem from task,problem where problem.task_number=task.task_number');
$sql2->execute();
	
	 //Confirm there are results
if ($result = $sql2->get_result())
{
 // We have results, create an array to hold the results
        // and an array to hold the data
 $resultArray = array();
 $tempArray = array();
 
 // Loop through each result
 while($row = $result->fetch_object())
 {
 // Add each result into the results array
 $tempArray = $row;
     array_push($resultArray, $tempArray);
 }
 
 // Encode the array to JSON and output the results
 echo json_encode($resultArray);
}

// Close connections
mysqli_close($connection);
	
?>