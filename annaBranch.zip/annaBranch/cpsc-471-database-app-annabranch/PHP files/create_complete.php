<?php

require "connection.php";
$task_number = $_POST["task_number"];
$Date = $_POST["Date"]; 
$timeSpent = $_POST["timeSpent"]; 
$ESSN = $_POST["ESSN"]; 

//Preventing sql injection..
$statement1 = $connection->prepare('insert into complete values (?,?,?,?)');
$statement1->bind_param('ssss',$task_number,$Date,$timeSpent,$ESSN);
$result1 = $statement1->execute();

if($result1){
	echo "Success";
}else{echo "Not successful";}
?>