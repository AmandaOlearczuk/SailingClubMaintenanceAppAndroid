<?php

require "connection.php";

$SerialNum = $_POST["SerialNum"];
$Type = $_POST["Type"];
$P_Condition = $_POST["P_Condition"];
$Man_Month = $_POST["Man_Month"];
$Man_Year = $_POST["Man_Year"];
$Pur_Date = $_POST["Pur_Date"];
$stock_Name = $_POST["stock_Name"];

$mysql_qry = "insert into part (SerialNum, Type, P_Condition, Man_Month, Man_Year, Pur_Date, stock_Name) values ('$SerialNum','$Type',$P_Condition,'$Man_Month','$Man_Year','$Pur_Date','$stock_Name')";

if($connection->query($mysql_qry)===TRUE){
echo "Part added";
}
else{
echo "Error: " . $mysql_qry . "<br>" . $connection->error;
}
 
$connection->close();

?>