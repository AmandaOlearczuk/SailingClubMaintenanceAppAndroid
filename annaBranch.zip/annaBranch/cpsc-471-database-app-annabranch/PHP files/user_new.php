<?php

require "connection.php";

$SSN = $_POST["SSN"];
$FirstName = $_POST["FirstName"];
$email = $_POST["email"];
$password = $_POST["password"];

$mysql_qry = "insert into employee (SSN, FirstName, email, password) values ('$SSN','$FirstName','$email','$password')";

if($connection->query($mysql_qry)===TRUE){
echo "User added";
}
else{
echo "Error: " . $mysql_qry . "<br>" . $connection->error;
}
 
$connection->close();

?>