<?php
require "connection.php";
$task_number = $_POST["task_number"];
$Boat_SerialNum = $_POST["Boat_SerialNum"]; 

//Preventing sql injection..
$statement1 = $connection->prepare('insert into relates_to values (?,?)');
$statement1->bind_param('ss',$task_number,$Boat_SerialNum);
$result1 = $statement1->execute();

if($result1){
	echo "Success";
}else{echo "Not successful";}
?>