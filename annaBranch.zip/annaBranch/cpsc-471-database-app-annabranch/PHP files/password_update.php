<?php

require "connection.php";

$SSN = $_POST["SSN"];
$password = $_POST["password"];


$mysql_qry = "update employee set password = '$password' where employee.SSN = '$SSN'";

if($connection->query($mysql_qry)===TRUE){
echo "Password changed";
}
else{
echo "Error: " . $mysql_qry . "<br>" . $connection->error;
}
 
$connection->close();

?>