<?php
require "connection.php";
$user_name = $_POST["user_name"]; //parameter for name (we get it from app)
$user_password = $_POST["user_password"]; //parameter for password (we get it from app)

//Preventing sql injection..
$statement = $connection->prepare('select * from employee where email like ? and password like ?');
$statement->bind_param('ss',$user_name,$user_password);

//$mysql_query = "select employee.ssn from employee where email like '$user_name' and password like '$user_password'";
//$result = mysqli_query($connection,$mysql_query);
$statement->execute();
$result = $statement->get_result();
$rowcount = mysqli_num_rows($result);
$row = mysqli_fetch_assoc($result);
$first_name = $row["FirstName"];
$ssn = $row["SSN"];
//printf("Result set has %d rows.\n",$rowcount);
if($rowcount > 0){
	echo "Welcome, " .$first_name ." !";
	echo ">".$ssn ; //This is the ssn we want to pass, so that the app knows who is logged in.
}else{
	echo "Login Failed";
}
?>