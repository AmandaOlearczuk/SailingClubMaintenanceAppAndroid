<?php
require "connection.php";
$task_number = $_POST["task_number"];
$problem = $_POST["problem"]; 

//Preventing sql injection..
$statement1 = $connection->prepare('insert into problem values (?,?)');
$statement1->bind_param('ss',$task_number,$problem);
$result1 = $statement1->execute();

if($result1){
	echo "Success";
}else{echo "Not successful";}
?>