<?php

require "connection.php";

$SSN = $_POST["SSN"];

$mysql_qry = "delete from employee where SSN = '$SSN'";


if($connection->query($mysql_qry)===TRUE){
echo "User deleted";
}
else{
echo "Error: " . $mysql_qry . "<br>" . $connection->error;
}
 
$connection->close();

?>