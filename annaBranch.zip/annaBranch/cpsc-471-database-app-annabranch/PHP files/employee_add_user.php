<?php
require "connection.php";

$ssn = $_POST["ssn"];
$email = $_POST["email"];
$password = $_POST["password"];
$is_admin = $_POST["is_admin"];
$admin_ID = $_POST["admin_ID"];
$isSupervisor = $_POST["isSupervisor"];

$mysql_qry = " insert into employee (ssn, email, password) values ('$ssn','$email','$password') ";

if($is_admin == 1){
$mysql_qry = " insert into admin (ssn, admin_ID) values ('$ssn','$admin_ID') ";
}
else{
$mysql_qry = " insert into staff (ssn, isSupervisor) values ('$ssn','$isSupervisor') ";
}

if($connection->query($mysql_qry) === TRUE){
echo "New employee added";
}
else{
echo "Error: " . $mysql_qry . "<br>" . $connection->error;
}

$connection->close();

?>