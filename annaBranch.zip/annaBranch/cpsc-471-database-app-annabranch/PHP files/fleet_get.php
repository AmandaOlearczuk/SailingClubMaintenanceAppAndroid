<?php
require "connection.php";

$sql = $connection->prepare('select SerialNum, Name, Class, Year, Status, date_added, Loc_Name, Hull_num from boat');
$sql->execute();
	
//Confirm there are results
if ($result = $sql->get_result())
{
 // We have results, create an array to hold the results
        // and an array to hold the data
 $resultArray = array();
 $tempArray = array();
 
 // Loop through each result
 while($row = $result->fetch_object())
 {
 // Add each result into the results array
 $tempArray = $row;
 $resultArray[] = $tempArray;
 }
 
 // Encode the array to JSON and output the results
 echo json_encode($resultArray);
}
?>
