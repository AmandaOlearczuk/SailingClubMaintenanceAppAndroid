<?php
require "connection.php";
//print_r($_POST);

$statement = $connection->prepare('select MAX(task_number) from task');

$statement->execute();
$result = $statement->get_result();
$rowcount = mysqli_num_rows($result);
$row = mysqli_fetch_row($result);

$one = 1;
$task_num = $row[0] + 1;

$title = $_POST["Title"];
$details = $_POST["Details"];

$creator_ssn = $_POST["creator_ssn"];
$date_created = $_POST["date_created"];

//Preventing sql injection..
$statement1 = $connection->prepare('insert into task values (?,?,?)');
$statement1->bind_param('sss',$task_num,$title,$details);
$result1 = $statement1->execute();

$statement2 = $connection->prepare('insert into creates values (?,?,?)');
$statement2->bind_param('sss',$task_num,$creator_ssn,$date_created);
$result2 = $statement2->execute();

if($result1){
	echo $task_num;
}else{echo "Not successful";}
?>