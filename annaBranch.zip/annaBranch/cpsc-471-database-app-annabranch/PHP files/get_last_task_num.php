<?php
require "connection.php";

//Preventing sql injection..
$statement = $connection->prepare('select MAX(task_number) from task');

$statement->execute();
$result = $statement->get_result();
$rowcount = mysqli_num_rows($result);
$row = mysqli_fetch_row($result);

if($rowcount > 0){
	echo $row[0];
}else{
	echo "0";
}
?>