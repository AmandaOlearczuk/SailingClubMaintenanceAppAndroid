<?php

require "connection.php";

$ssn = $_POST["ssn"];
$title = $_POST["title"];
$content = $_POST["content"];

$mysql_qry = "insert into note (ssn, title, content) values ('$ssn','$title','$content')";

if($connection->query($mysql_qry)===TRUE){
echo "Saved";
}
else{
echo "Error: " . $mysql_qry . "<br>" . $connection->error;
}
 
$connection->close();

?>