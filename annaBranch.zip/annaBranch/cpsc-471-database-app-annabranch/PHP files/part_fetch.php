<?php
require "connection.php";

$sql = $connection->prepare('select SerialNum, Type, P_Condition, Man_Month, Man_Year, Pur_Date, stock_Name from part');
$sql->execute();

if ($result = $sql->get_result())
{
 $resultArray = array();
 $tempArray = array();
 
 while($row = $result->fetch_object())
 {
 $tempArray = $row;
 $resultArray[] = $tempArray;
 }
 
 // Encode the array to JSON and output the results
 echo json_encode($resultArray);
}


?>