<?php
require "connection.php";
$task_number = $_POST["task_number"];
$issue = $_POST["issue"]; 

//Preventing sql injection..
$statement1 = $connection->prepare('insert into issue values (?,?)');
$statement1->bind_param('ss',$task_number,$issue);
$result1 = $statement1->execute();

if($result1){
	echo "Success";
}else{echo "Not successful";}
?>