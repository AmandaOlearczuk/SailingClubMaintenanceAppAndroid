package com.example.sailingclubmaintenance.login;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.EditText;

import com.example.sailingclubmaintenance.R;

/**
 * This Activity (Screen) is responsible for log in of the employee.
 */
public class LoginActivity extends AppCompatActivity {

    EditText usernameEt ,passwordEt;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameEt = (EditText)findViewById(R.id.username);
        passwordEt = (EditText)findViewById(R.id.password);


    }

    /**
     * Method to handle what happens when user clicks LOG IN button.
     * @param view
     */
    public void OnLogin(View view) {
        String username = usernameEt.getText().toString();
        String password = passwordEt.getText().toString();
        String type ="login";

        DatabaseLoginConnection dbconnectionLogin = new DatabaseLoginConnection(this);
        //Execute login query with username & password
        dbconnectionLogin.execute(type,username,password);

    }
}
