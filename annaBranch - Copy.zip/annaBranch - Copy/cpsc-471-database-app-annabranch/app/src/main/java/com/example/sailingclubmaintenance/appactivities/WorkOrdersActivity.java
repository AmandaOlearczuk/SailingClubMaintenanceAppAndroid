package com.example.sailingclubmaintenance.appactivities;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.sailingclubmaintenance.Database.DatabaseDeleteTask;
import com.example.sailingclubmaintenance.Database.DatabaseWorkOrderFetching;
import com.example.sailingclubmaintenance.Database.FetchingTasksForWorkOrderDelete;
import com.example.sailingclubmaintenance.Other.WorkOrder;
import com.example.sailingclubmaintenance.Other.WorkOrderAdapter;
import com.example.sailingclubmaintenance.R;
import com.example.sailingclubmaintenance.login.Globals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class WorkOrdersActivity extends AppCompatActivity {

    //a list to store all the work orders
    List<WorkOrder> workOrderList;

    //the recyclerview
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_work_orders);

        //getting the recyclerview from xml
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //Slowly building up our items to create work orders

        workOrderList = new ArrayList<>();

        for(String workOrderNum: Globals.tempWorkOrdersResult.keySet()) { //For each work order
            HashMap<String, ArrayList<String>> currentDictionary = DatabaseWorkOrderFetching.resultMap.get(workOrderNum);//hashmap for that work order
            String statusOfWorkOrder;

            String SerialNum = "";
            String Boat_Class = "";

            try{ //Check if this work order has any boat assigned to it at all
                SerialNum = currentDictionary.get("SerialNum").get(0);
                Boat_Class = currentDictionary.get("Class").get(0);
            } catch(IndexOutOfBoundsException e){} //No boat for this task is assigned - completly ok

            if(currentDictionary.get("dateCompleted") == null || currentDictionary.get("dateCompleted").size() == 0){
                statusOfWorkOrder = "IN PROGRESS";
                System.out.println("Processing IN PROGRESS task...");
                System.out.println(currentDictionary.toString());

                workOrderList.add(
                        new WorkOrder(Integer.parseInt(workOrderNum),currentDictionary.get("Title").get(0),
                                SerialNum,
                                Boat_Class, currentDictionary.get("problem"), currentDictionary.get("issue"),
                                currentDictionary.get("Details").get(0), statusOfWorkOrder,
                                "", "","",
                                currentDictionary.get("partNum"),currentDictionary.get("FirstName").get(0),
                                currentDictionary.get("LastName").get(0),currentDictionary.get("dateCreated").get(0)));

            }else {
                statusOfWorkOrder = "COMPLETED";

                System.out.println("Processing COMPLETED task...");
                System.out.println(currentDictionary.toString());

                workOrderList.add(
                        new WorkOrder(Integer.parseInt(workOrderNum),currentDictionary.get("Title").get(0),
                                SerialNum, Boat_Class, currentDictionary.get("problem"), currentDictionary.get("issue"),
                                currentDictionary.get("Details").get(0), statusOfWorkOrder,
                                currentDictionary.get("completeFN").get(0), currentDictionary.get("completeLN").get(0),
                                currentDictionary.get("dateCompleted").get(0),currentDictionary.get("partNum"), //parts used
                                currentDictionary.get("FirstName").get(0),
                                currentDictionary.get("LastName").get(0),currentDictionary.get("dateCreated").get(0)));
            }
        }

        //Displays a list of work orders -we need to create Adapter to pass to recycler view below.
        WorkOrderAdapter adapter = new WorkOrderAdapter(this, workOrderList);

        //setting adapter to recyclerview
        recyclerView.setAdapter(adapter);
    }

    /**
     * Method to handle what happens when user clicks NEW (work order button)
     * @param view
     */
    public void onNewWorkOrder(View view) {
        Intent intent = new Intent(this, NewWorkOrderActivity.class);
        startActivity(intent);
        finish();

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, MainMenu.class); //context is screen that we called this method from (login screen)
        this.startActivity(intent);
    }

    /**
     * Button to refresh work orders
     * @param view
     */
    public void Refresh(View view) {
        DatabaseWorkOrderFetching workOrderFetching = new DatabaseWorkOrderFetching(this);
        AlertDialog.Builder ad = new AlertDialog.Builder(this).setMessage("Please wait..").setCancelable(false);
        ad.show();
        //Execute fetching of work orders from the server
        workOrderFetching.execute();
    }

    public void Delete(View view) {

        final Spinner taskNumsSpinner = new Spinner(this);

        FetchingTasksForWorkOrderDelete fetchingTasksForWorkOrderDelete = new FetchingTasksForWorkOrderDelete(this);
        //Execute login query with username & password
        fetchingTasksForWorkOrderDelete.execute(taskNumsSpinner);

        AlertDialog.Builder alert = new AlertDialog.Builder(this);

        alert.setTitle("Delete Work Order");
        alert.setMessage("Work order number:");

        // Set an EditText view to get user input

        alert.setView(taskNumsSpinner);

        alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {

                DatabaseDeleteTask databaseDeleteTask = new DatabaseDeleteTask(WorkOrdersActivity.this);
                databaseDeleteTask.execute(taskNumsSpinner.getSelectedItem().toString());
            }
        });

        alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                // Canceled.
            }
        });

        alert.show();
    }
}
