package com.example.sailingclubmaintenance.Database;

import android.content.Context;
import android.os.AsyncTask;

import androidx.appcompat.app.AlertDialog;

import com.example.sailingclubmaintenance.login.Globals;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

/**
 * This class deals with retrieving login information from the database.
 * If it's successful, main menu will be opened.
 */
public class DatabaseCreatingNewTask extends AsyncTask<ArrayList<String>,Void, String> {

    private Context context;
    ArrayList<String> task_table_info;
    ArrayList<String> problem_table_info ;
    ArrayList<String> issue_table_info;
    ArrayList<String> parts_used_table_info;
    ArrayList<String> boat_and_timespent_table_info;
    AlertDialog.Builder ad;
    DatabaseCreatingNewIssue databaseCreatingNewIssue;
    DatabaseCreatingNewUsed databaseCreatingNewUsed;
    DatabaseCreatingNewProblem databaseCreatingNewProblem;
    DatabaseCreatingRelatesTo databaseCreatingRelatesTo;
    DatabaseCreatingComplete databaseCreatingCreates;


    //Constructor
    public DatabaseCreatingNewTask(Context ctx) {
        context = ctx;
    }

    @Override
    protected String doInBackground(ArrayList<String>... params) {

        AlertDialog.Builder ad = new AlertDialog.Builder(context).setMessage("Creating work order..").setCancelable(false);
        ad.show();

        task_table_info = params[0];
        problem_table_info = params[1];
        issue_table_info = params[2];
        parts_used_table_info = params[3];
        boat_and_timespent_table_info = params[4];

        String yourIPV4 = Globals.yourIPV4;
        String create_task_url = "http://"+ yourIPV4 +"/create_task.php";

            try {

                String Title = task_table_info.get(0); //Get the passed username from user
                String Details = task_table_info.get(1); //get the passed password from user
                String creator_ssn = task_table_info.get(2);
                String date_created = task_table_info.get(3);
                URL url = new URL(create_task_url); //set url to which we will post this info
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST"); //make sure we are posting
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
                //Write the following data..
                String post_data = URLEncoder.encode("Title","UTF-8")+"="+URLEncoder.encode(Title,"UTF-8")
                        +"&"+URLEncoder.encode("Details","UTF-8")+"="+URLEncoder.encode(Details,"UTF-8")
                        +"&"+URLEncoder.encode("creator_ssn","UTF-8")+"="+URLEncoder.encode(creator_ssn,"UTF-8")
                        +"&"+URLEncoder.encode("date_created","UTF-8")+"="+URLEncoder.encode(date_created,"UTF-8");
                bufferedWriter.write(post_data);
                //Flush and close everything
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                //Now, we would like to recieve the result
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result = "";
                String line;
                while((line = bufferedReader.readLine()) !=null){ //reading the result line by line
                    result+=line;
                }
                //Log.d("myTag",result);
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                System.out.println("Result of creating new task query is: " + result);
                return result;


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }



        return null;
    }

    @Override //This executes before we even start querying
    protected void onPreExecute() {

    }

    @Override //This executes after we recieved response from server - result is the response
    protected void onPostExecute(String result) {
        Globals.lastTaskNum = result;

        //Create problem tables
        try{ databaseCreatingNewProblem = new DatabaseCreatingNewProblem(context);
        for(String problem: problem_table_info){
            databaseCreatingNewProblem.execute(Globals.lastTaskNum,problem);
            }
        }catch(IllegalStateException e){
            for(String problem: problem_table_info){
                new DatabaseCreatingNewProblem(context).execute(Globals.lastTaskNum,problem);
            }
        }

        //Create issue tables

        try{
            databaseCreatingNewIssue = new DatabaseCreatingNewIssue(context);
        for(String issue: issue_table_info) {
            databaseCreatingNewIssue.execute(Globals.lastTaskNum, issue);
            }
        }catch(IllegalStateException ex ){
            for (String issue : issue_table_info) {
                new DatabaseCreatingNewIssue(context).execute(Globals.lastTaskNum, issue);
            }
        }

        //Create parts used table
        try{
         DatabaseCreatingNewUsed databaseCreatingNewUsed = new DatabaseCreatingNewUsed(context);
            for (String used : parts_used_table_info) {
                System.out.println("In 1st FOR LOOP");
            databaseCreatingNewUsed.execute(Globals.lastTaskNum, used);
            }
        }catch(Exception e){
            System.out.println("Illegal state exception CATCH");
            for (String used : parts_used_table_info) {
                System.out.println("In 2nd FOR LOOP");
            new DatabaseCreatingNewUsed(context).execute(Globals.lastTaskNum, used);
            }
        }

        //Create boat entry
        if(!boat_and_timespent_table_info.get(0).equals("None")) {

            try{
                databaseCreatingRelatesTo = new DatabaseCreatingRelatesTo(context);
                databaseCreatingRelatesTo.execute(Globals.lastTaskNum, boat_and_timespent_table_info.get(0));}
            catch(Exception e){
                databaseCreatingRelatesTo.execute(Globals.lastTaskNum, boat_and_timespent_table_info.get(0));}
        }

        //Create complete entry
        if(!boat_and_timespent_table_info.get(1).equals("")){
            try{
                databaseCreatingCreates = new DatabaseCreatingComplete(context);
                databaseCreatingCreates.execute(Globals.lastTaskNum,boat_and_timespent_table_info.get(1));}
            catch(Exception e){
                databaseCreatingCreates.execute(Globals.lastTaskNum,boat_and_timespent_table_info.get(1));}
        }


    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }


}


