package com.example.sailingclubmaintenance.Database;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;

import com.example.sailingclubmaintenance.appactivities.MainMenu;
import com.example.sailingclubmaintenance.login.Globals;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * This class deals with retrieving login information from the database.
 * If it's successful, main menu will be opened.
 */
public class DatabaseLoginConnection extends AsyncTask<String,Void,String> {

    private Context context;
    private AlertDialog alertDialogLogin;

    //Constructor
    public DatabaseLoginConnection(Context ctx) {
        context = ctx;
    }

    @Override
    protected String doInBackground(String... params) {
        String type = params[0]; //Type of query we want
        String yourIPV4 = Globals.yourIPV4;
        String login_url = "http://"+ yourIPV4 +"/login.php"; //your ipv4 address, and php file you want to execute
        if(type.equals("login")){ //Check what type of query it is
            try {
                String user_name = params[1]; //Get the passed username from user
                String user_password = params[2]; //get the passed password from user
                URL url = new URL(login_url); //set url to which we will post this info
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST"); //make sure we are posting
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
                //Write the following data..
                String post_data = URLEncoder.encode("user_name","UTF-8")+"="+URLEncoder.encode(user_name,"UTF-8")
                        +"&"+URLEncoder.encode("user_password","UTF-8")+"="+URLEncoder.encode(user_password,"UTF-8");
                bufferedWriter.write(post_data);
                //Flush and close everything
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                //Now, we would like to recieve the result
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result = "";
                String line;
                while((line = bufferedReader.readLine()) !=null){ //reading the result line by line
                    result+=line;
                }
                //Log.d("myTag",result);
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        return null;
    }

    @Override //This executes before we even start querying
    protected void onPreExecute() {
        alertDialogLogin = new AlertDialog.Builder(context).create();
        alertDialogLogin.setTitle("Login Status");
    }

    @Override //This executes after we recieved response from server - result is the response
    protected void onPostExecute(String result) {
        if (result.contains(">")) { //Success of login
            String[] myResult = result.split(">");
            Globals.currentSSN = myResult[1]; //ssn of the user
            //alertDialogLogin.setMessage(myResult[0]); //Welcome message
            //alertDialogLogin.show();
        }
        else{
            Globals.currentSSN = "";
            alertDialogLogin.setMessage(result); //Welcome message
            alertDialogLogin.show();
        }

        if(Globals.currentSSN != "") {
            openActivityMainMenu();
        }
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    public void openActivityMainMenu(){

        Intent intent = new Intent(context, MainMenu.class); //context is screen that we called this method from (login screen)
        context.startActivity(intent);
        //((Activity)context).finish(); //kill the login activity

    }
}


