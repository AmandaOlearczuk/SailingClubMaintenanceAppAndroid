package com.example.sailingclubmaintenance.fleetexpandable;

import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup;

import java.util.Collections;
import java.util.List;

public class BoatType extends ExpandableGroup<Boat> {
    private String typeName;
    private List<Boat> typeMembers;

    public BoatType(String newTypeName, List<Boat> newMembers) {
        super(newTypeName,newMembers);
        typeName = newTypeName;
        typeMembers = newMembers;
    }

    public String getTypeName() {
        return typeName;
    }
    public int getFleetSize() {
        int size = typeMembers.size();
        return size;
    }

    public void removeMember(Boat toRemove) {
        typeMembers.remove(toRemove);
    }
    public void addMember(Boat toAdd, boolean isAdmin) {
        if (isAdmin) {
            typeMembers.add(toAdd);
            sortByHullNumber();
        }
    }
    public void sortByHullNumber() {
        Collections.sort(typeMembers);
    }
}
