package com.example.sailingclubmaintenance.Notes;

import android.content.Context;
import android.os.AsyncTask;

import com.example.sailingclubmaintenance.appactivities.ToDoActivity;
import com.example.sailingclubmaintenance.login.Globals;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;


public class DatabaseFetchNotes extends AsyncTask<String,Void,String> {
    Context context;

    public DatabaseFetchNotes(Context ctx){
        context = ctx;
    }

    @Override
    protected String doInBackground(String... params) {
        String type = params[0];
        String getNotes_url = "http://"+ Globals.yourIPV4+"/note_fetch.php";
        if(type.equals("loadNotes")) {
            try {
                URL url = new URL(getNotes_url); //set url to which we will post this info
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST"); //make sure we are posting
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);

                //Now, we would like to recieve the result
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result = "";
                String line;
                while((line = bufferedReader.readLine()) !=null){ //reading the result line by line
                    result+=line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                System.out.println("Result is.." + result);
                return result;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String result) {
        System.out.println("Notes: " + result);
        Globals.noteList = new ArrayList<>();
        try{
            JSONArray array = new JSONArray(result);

            for (int i = 0; i < array.length(); i++) {
                JSONObject note = array.getJSONObject(i);
                Globals.noteList.add(new Note(
                        note.getInt("noteID"),
                        note.getString("SSN"),
                        note.getString("title"),
                        note.getString("content")
                ));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        NotesAdapter adapter = new NotesAdapter(context, Globals.noteList);
        ToDoActivity.recyclerView.setAdapter(adapter);

       // ToDoActivity.refreshNotes(result);

    }


    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

}
