package com.example.sailingclubmaintenance.Parts;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.sailingclubmaintenance.R;
import com.example.sailingclubmaintenance.appactivities.PartsActivity;

public class NewPart extends AppCompatActivity {
    
    int partID;
    EditText partType, partSerialNum, partCondition, partManDate, partPurDate, partStockName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_part);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        partType = findViewById(R.id.editTextPType);
        partSerialNum = findViewById(R.id.editTextPSerialNum);
        partCondition = findViewById(R.id.editTextPCondition);
        partManDate = findViewById(R.id.editTextPMD);
        partPurDate = findViewById(R.id.editTextPPD);
        partStockName = findViewById(R.id.editTextPStockName);


    }

    //Create new part button
    public void createNewPart(View view){
        //String noteID = String.valueOf(this.noteID);
        String str_type = partType.getText().toString();
        String str_serialNum = partSerialNum.getText().toString();
        String str_condition = partCondition.getText().toString();
        //get manufacturing date string values
        String str_manDate = partManDate.getText().toString();
        char charAt0 = str_manDate.charAt(0);
        char charAt1 = str_manDate.charAt(1);
        String str_manDateMonth = String.valueOf(charAt0)+String.valueOf(charAt1);
        char charAt3 = str_manDate.charAt(3);
        char charAt4 = str_manDate.charAt(4);
        char charAt5 = str_manDate.charAt(5);
        char charAt6 = str_manDate.charAt(6);
        String str_manDateYear = String.valueOf(charAt3)+String.valueOf(charAt4)+String.valueOf(charAt5)+String.valueOf(charAt6);
        //get purchase date string values
        String str_purDate = partPurDate.getText().toString();
        String str_stockName = partStockName.getText().toString();

        String type = "saveNewPart";

        DatabasePartsTable dbNote = new DatabasePartsTable(this);
        dbNote.execute(type, str_type, str_serialNum, str_condition, str_manDateMonth, str_manDateYear, str_purDate, str_stockName);

        Intent intent = new Intent(getApplicationContext(), PartsActivity.class);
        startActivity(intent);

    }

}
