package com.example.sailingclubmaintenance.appactivities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sailingclubmaintenance.R;
import com.example.sailingclubmaintenance.Notes.DatabaseFetchNotes;
import com.example.sailingclubmaintenance.Notes.NewNote;
import com.example.sailingclubmaintenance.Notes.Note;
import com.example.sailingclubmaintenance.Notes.NotesAdapter;
import com.example.sailingclubmaintenance.login.Globals;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class ToDoActivity extends AppCompatActivity {

    public static RecyclerView recyclerView;

    public static List<Note> refreshNotes(String result) {
        Globals.noteList = new ArrayList<>();
        try{
            JSONArray array = new JSONArray(result);

            for (int i = 0; i < array.length(); i++) {
                JSONObject note = array.getJSONObject(i);
                Globals.noteList.add(new Note(
                        note.getInt("noteID"),
                        note.getString("SSN"),
                        note.getString("title"),
                        note.getString("content")
                ));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return Globals.noteList;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_do);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        String type = "loadNotes";
        DatabaseFetchNotes dbFetchNotes = new DatabaseFetchNotes(this);
        dbFetchNotes.execute(type);

        recyclerView = (RecyclerView) findViewById(R.id.notes_list);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));




        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Set fab to create new task to add to list
                onNewNote();
            }
        });

    }


    //creates new note instance
    public void onNewNote() {
        Intent intent = new Intent(getApplicationContext(), NewNote.class);
        startActivity(intent);
        //assign new noteID

    }


}
