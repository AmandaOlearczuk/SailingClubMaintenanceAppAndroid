package com.example.sailingclubmaintenance.Settings;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.sailingclubmaintenance.R;

public class AddNewUser extends AppCompatActivity {

    EditText firstName, ssn, email, password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_user);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        firstName = (EditText)findViewById(R.id.et_firstName);
        ssn = (EditText)findViewById(R.id.et_ssn);
        email = (EditText)findViewById(R.id.et_email);
        password = (EditText)findViewById(R.id.et_password);

    }

    public void addBtn(View view) {

        String str_firstName = firstName.getText().toString();
        String str_ssn = ssn.getText().toString();
        String str_email = email.getText().toString();
        String str_password = password.getText().toString();

        // initiate switch
        Switch adminSwtich = (Switch) findViewById(R.id.AdminSwitch);
        // check current state of a Switch (true or false).
        Boolean switchState = adminSwtich.isChecked();

        if (switchState == true){
            String adminSSN = ssn.getText().toString();
            String type = "addAdmin";
            DatabaseAddRemoveUser dbUser = new DatabaseAddRemoveUser(this);
            dbUser.execute(type, adminSSN);
        }

        String type = "addNewUser";

        DatabaseAddRemoveUser dbUser = new DatabaseAddRemoveUser(this);
        dbUser.execute(type, str_ssn, str_firstName, str_email, str_password);

    }
}
