package com.example.sailingclubmaintenance.Notes;

import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;

import com.example.sailingclubmaintenance.login.Globals;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;


/**
 * This class retrieves note table from database
 */
public class DatabaseNoteTable extends AsyncTask<String,Void,String> {

    private Context context;
    private AlertDialog alertDialogNote;

    //Constructor
    public DatabaseNoteTable(Context ctx) {
        context = ctx;
    }

    @Override
    protected String doInBackground(String... params) {
        String type = params[0]; //Type of query we want
        String yourIPV4 = Globals.yourIPV4;

        String newNote_url = "http://"+yourIPV4+"/note_new.php";
        String deleteNote_url = "http://"+yourIPV4+"/note_delete.php";

        if(type.equals("saveNewNote")){ //Check what type of query it is
            try {
                String ssn = params[1];
                String title = params[2];//Get the passed username from user
                String content = params[3]; //get the passed password from user
                URL url = new URL(newNote_url); //set url to which we will post this info
                HttpURLConnection httpURLConnection = (HttpURLConnection)    url.openConnection();
                httpURLConnection.setRequestMethod("POST"); //make sure we are posting
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
                //Write the following data..
                String post_data = URLEncoder.encode("ssn","UTF-8")+"="+URLEncoder.encode(ssn,"UTF-8")
                        +"&"+URLEncoder.encode("title","UTF-8")+"="+URLEncoder.encode(title,"UTF-8")
                        +"&"+URLEncoder.encode("content","UTF-8")+"="+URLEncoder.encode(content,"UTF-8");
                bufferedWriter.write(post_data);
                //Flush and close everything
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                //Now, we would like to recieve the result
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result =  "";
                String line="";
                while((line = bufferedReader.readLine()) !=null){ //reading the result line by line
                    result+=line;
                }
                //Log.d("myTag",result);
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }else if (type.equals("deleteNote")){
            try {
                String ssn = params[1];
                String title = params[2];//Get the passed username from user
                String content = params[3]; //get the passed password from user
                URL url = new URL(deleteNote_url); //set url to which we will post this info
                HttpURLConnection httpURLConnection = (HttpURLConnection)    url.openConnection();
                httpURLConnection.setRequestMethod("POST"); //make sure we are posting
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
                //Write the following data..
                String post_data = URLEncoder.encode("ssn","UTF-8")+"="+URLEncoder.encode(ssn,"UTF-8")
                        +"&"+URLEncoder.encode("title","UTF-8")+"="+URLEncoder.encode(title,"UTF-8")
                        +"&"+URLEncoder.encode("content","UTF-8")+"="+URLEncoder.encode(content,"UTF-8");
                bufferedWriter.write(post_data);
                //Flush and close everything
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                //Now, we would like to receive the result
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result =  "";
                String line="";
                while((line = bufferedReader.readLine()) !=null){ //reading the result line by line
                    result+=line;
                }
                //Log.d("myTag",result);
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

                return null;
    }

    @Override
    protected void onPreExecute() {
        alertDialogNote = new AlertDialog.Builder(context).create();
        alertDialogNote.setTitle("Message");
    }

    @Override
    protected void onPostExecute(String result) {
        alertDialogNote.setMessage(result);
        alertDialogNote.show();
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }



}
