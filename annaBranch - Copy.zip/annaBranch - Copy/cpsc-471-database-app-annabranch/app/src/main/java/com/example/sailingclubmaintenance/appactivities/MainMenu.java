package com.example.sailingclubmaintenance.appactivities;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.view.Menu;
import android.widget.Toast;

import com.example.sailingclubmaintenance.Database.DatabaseWorkOrderFetching;
import com.example.sailingclubmaintenance.R;
import com.example.sailingclubmaintenance.Settings.SettingsActivity;
import com.example.sailingclubmaintenance.login.Globals;
import com.example.sailingclubmaintenance.login.LoginActivity;

public class MainMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        // TOOLBAR!
       // Toolbar toolbar = findViewById(R.id.general_toolbar);
        //setSupportActionBar(toolbar);
        // TOOLBAR! Use this to set the title in each window
        //toolbar.setTitle(getString(R.string.title_activity_main_menu));

        // Button to continue to Fleet activity
        Button fleetButton = findViewById(R.id.fleet_button);
        fleetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String type = "datainit";
                setUpFleetDB(type);
            }
        });

        // Button to continue to Parts activity
        Button partsButton = findViewById(R.id.parts_button);
        partsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), PartsActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });

        Button maintenanceButton = findViewById(R.id.maintenance_button);
        maintenanceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseWorkOrderFetching workOrderFetching = new DatabaseWorkOrderFetching(view.getContext());
                AlertDialog.Builder ad = new AlertDialog.Builder(view.getContext()).setMessage("Please wait..").setCancelable(false);
                ad.show();
                //Execute fetching of work orders from the server
                workOrderFetching.execute();
            }
        });

        // Button to continue to To Do activity
        Button toDoButton = findViewById(R.id.todo_list_button);
        toDoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), ToDoActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });

        // Button to continue to Settings activity
        Button settingsButton = findViewById(R.id.settings_button);
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), SettingsActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });
    }

    // TOOLBAR! Add the next two things to deal with toolbars (1/2)
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    // TOOLBAR! Handles onclicks for the toolbar (2/2)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.toolbar_to_do) {
            Toast.makeText(MainMenu.this, "move to 'To Do'", Toast.LENGTH_LONG).show();
            return true;
        }

        if (id == R.id.toolbar_main_menu) {
            Toast.makeText(MainMenu.this, "move to 'Main Menu'", Toast.LENGTH_LONG).show();
            return true;
        }

        if (id == R.id.toolbar_log_out) {
            Toast.makeText(MainMenu.this, "move to 'Log Out'", Toast.LENGTH_LONG).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void OnSignOut(View view) {
        Globals.currentSSN = "";
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    public void setUpFleetDB(String type) {
        FleetConnection fleetConnection = new FleetConnection(this);
        fleetConnection.execute(type);
    }

    @Override
    public void onBackPressed() {
//Do nothing!
    }
}
