package com.example.sailingclubmaintenance.fleetexpandable;

import android.view.View;
import android.widget.TextView;

import com.example.sailingclubmaintenance.R;
import com.thoughtbot.expandablerecyclerview.viewholders.ChildViewHolder;

public class BoatViewHolder extends ChildViewHolder {
    private TextView numberTextView;
    private TextView nameTextView;
    private TextView serialTextView;
    private TextView locationTextView;
    private TextView yearTextView;
    private TextView dateAddedTextView;
    private TextView statusTextView;

    public BoatViewHolder(View itemView) {
        super(itemView);
        numberTextView = itemView.findViewById(R.id.textViewNum);
        nameTextView = itemView.findViewById(R.id.textViewName);

        serialTextView = itemView.findViewById(R.id.boat_serial_print);
        locationTextView = itemView.findViewById(R.id.boat_location_print);
        yearTextView = itemView.findViewById(R.id.boat_year_print);
        dateAddedTextView = itemView.findViewById(R.id.boat_date_print);
        statusTextView = itemView.findViewById(R.id.boat_status_print);
    }

    public void bind(Boat boat) {
        numberTextView.setText(Integer.toString(boat.getHullNumber()));
        nameTextView.setText(boat.getName());
        if (boat.getStatus().equals(null)) {statusTextView.setVisibility(View.GONE); }
        else {statusTextView.setText(boat.getStatus());
        }
        if (boat.getSerialNum()== -1) {serialTextView.setVisibility(View.GONE); }
        else {serialTextView.setText(Integer.toString(boat.getSerialNum()));
        }
        if (boat.getLocation().equals(null)) {locationTextView.setVisibility(View.GONE); }
        else {locationTextView.setText(boat.getLocation());
        }
        if (boat.getYear()== -1) {yearTextView.setVisibility(View.GONE); }
        else {yearTextView.setText(Integer.toString(boat.getYear()));
        }
        if (boat.getDateAdded().equals(null)) {dateAddedTextView.setVisibility(View.GONE); }
        else {dateAddedTextView.setText(boat.getDateAdded());
        }
    }
}
