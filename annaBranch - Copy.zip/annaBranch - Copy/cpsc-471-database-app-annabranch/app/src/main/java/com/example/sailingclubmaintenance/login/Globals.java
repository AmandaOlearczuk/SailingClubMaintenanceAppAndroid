package com.example.sailingclubmaintenance.login;

import com.example.sailingclubmaintenance.Notes.Note;
import com.example.sailingclubmaintenance.Parts.Part;
import com.example.sailingclubmaintenance.fleetexpandable.BoatType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class keeps track of things like current employee signed in etc..
 */
public class Globals {
    public static String currentSSN = "";
    public static String yourIPV4 = "192.168.0.22";

    public static Map<String, HashMap<String, ArrayList<String>>> tempWorkOrdersResult;
    public static String lastTaskNum = "";

    public static ArrayList<BoatType> sortedBoats;

    public static List<Part> partsList;
    public static List<Note> noteList;
}
