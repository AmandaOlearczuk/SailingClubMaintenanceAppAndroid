package com.example.sailingclubmaintenance.appactivities;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.sailingclubmaintenance.Database.DatabaseCreatingNewTask;
import com.example.sailingclubmaintenance.Database.FetchingBoatsForWorkOrder;
import com.example.sailingclubmaintenance.R;
import com.example.sailingclubmaintenance.login.Globals;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.regex.Pattern;

public class NewWorkOrderActivity extends AppCompatActivity {

    Spinner boatSpinner;
    CheckBox reattachCB,replaceCB,missing_requiresCB,repairCB; //Problem
    CheckBox blockCB,boomVangCB,bumperCB,bungeeCB,cleaningCB,cleatCB,cunninghamCB,fairleadCB,fibreglassCB,
    goosepinCB,gudgeonCB,halyardCB,hikingstrapCB,mastballCB,painterCB,plugCB,shroudCB,spreaderCB,
            tackpinCB,whistleCB,otherCB;//issue
    TextView titleText,boatText,problemsText,detailsText,parts_usedText,timeSpentText;
    EditText titleInput,detailsInput,parts_usedInput,time_spentInput,other_issueInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_work_order);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Problem section
        reattachCB = findViewById(R.id.checkBoxReattach);
        replaceCB = findViewById(R.id.checkBoxReplace);
        missing_requiresCB = findViewById(R.id.checkBoxMissingRequires);
        repairCB = findViewById(R.id.checkBoxRepair);

        //Issue section
        blockCB = findViewById(R.id.checkBoxBlock);
        boomVangCB = findViewById(R.id.checkBoxBoom);
        bumperCB = findViewById(R.id.checkBoxBumper);
        bungeeCB = findViewById(R.id.checkBoxBungee);
        cleaningCB = findViewById(R.id.checkBoxCleaning);
        cleatCB = findViewById(R.id.checkBoxCleaning);
        cunninghamCB = findViewById(R.id.checkBoxCunn);
        fairleadCB = findViewById(R.id.checkBoxFairlead);
        fibreglassCB = findViewById(R.id.checkBoxFibreglass);
        goosepinCB = findViewById(R.id.checkBoxGoose);
        gudgeonCB = findViewById(R.id.checkBoxGudgeon);
        halyardCB = findViewById(R.id.checkBoxHalyard);
        hikingstrapCB = findViewById(R.id.checkBoxHalyard);
        mastballCB = findViewById(R.id.checkBoxMastball);
        painterCB = findViewById(R.id.checkBoxPainter);
        plugCB = findViewById(R.id.checkBoxPlug);
        shroudCB = findViewById(R.id.checkBoxShroud);
        spreaderCB = findViewById(R.id.checkBoxSpreader);
        tackpinCB = findViewById(R.id.checkBoxTackPin);
        whistleCB = findViewById(R.id.checkBoxwhistle);
        otherCB = findViewById(R.id.checkBoxOther);

       //Section for of fields like Title: Details: Time:

        titleText = findViewById(R.id.textViewTitle1);
        boatText = findViewById(R.id.textViewBoat_1);
        problemsText = findViewById(R.id.problemsText_1);
        detailsText = findViewById(R.id.textViewDetails_1);
        parts_usedText = findViewById(R.id.textViewPartsUsed_1);
        timeSpentText = findViewById(R.id.textViewTimeSpent_1);

        //Section for input fields
        titleInput = findViewById(R.id.editTextTitle);
        detailsInput = findViewById(R.id.editTextDetails_1);
        parts_usedInput = findViewById(R.id.editTextPartsUsed_1);
        time_spentInput = findViewById(R.id.editTextTimeSpent_1);
        other_issueInput = findViewById(R.id.editTextOtherIssue_1);

        //Boat selection spinner
        boatSpinner = findViewById(R.id.boatSelectSpinner);



        FetchingBoatsForWorkOrder dbconnectionFetchBoats = new FetchingBoatsForWorkOrder(this);
        //Execute login query with username & password
        dbconnectionFetchBoats.execute(boatSpinner);

    }

    /**
     * This happens when you click CANCEL button
     * @param view
     */
    public void onCancel(View view) {
        Intent intent = new Intent(this, WorkOrdersActivity.class);
        startActivity(intent);
        finish();
    }

    /**
     * This happens when you click CREATE button for work order
     * @param view
     */
    public void OnCreateWorkOrder(View view) throws InterruptedException {

        Date date = new Date();
        String currentDate= new SimpleDateFormat("yyyy-MM-dd").format(date);

        //Pull info from fields
        String title = titleInput.getText().toString().trim();
        String boat = "None";
        try{ boat = boatSpinner.getSelectedItem().toString();}catch(NullPointerException e){}
        String other = other_issueInput.getText().toString().trim();
        String details = detailsInput.getText().toString().trim();
        String partsused = parts_usedInput.getText().toString().trim();
        String timespent = time_spentInput.getText().toString().trim();

        //problems
        Boolean is_reattachCB = reattachCB.isChecked();
        Boolean is_replaceCB = replaceCB.isChecked();
        Boolean is_missingrequiresCB = missing_requiresCB.isChecked();
        Boolean is_repairCB = repairCB.isChecked();

        //issues
        Boolean is_blockCB = blockCB.isChecked();
        Boolean is_boomCB = boomVangCB.isChecked();
        Boolean is_bumperCB = bumperCB.isChecked();
        Boolean is_bungeeCB = bungeeCB.isChecked();
        Boolean is_cleaningCB = cleaningCB.isChecked();
        Boolean is_cleatCB = cleatCB.isChecked();
        Boolean is_cunninghamCB = cunninghamCB.isChecked();
        Boolean is_fairleadCB = fairleadCB.isChecked();
        Boolean is_fibreglassCB = fibreglassCB.isChecked();
        Boolean is_goosepinCB = goosepinCB.isChecked();
        Boolean is_OtherCB = otherCB.isChecked();
        Boolean is_gudgeonCB = gudgeonCB.isChecked();
        Boolean is_halyardCB = halyardCB.isChecked();
        Boolean is_hikingstrapCB = hikingstrapCB.isChecked();
        Boolean is_mastballCB = mastballCB.isChecked();
        Boolean is_painterCB = painterCB.isChecked();
        Boolean is_plugCB = plugCB.isChecked();
        Boolean is_shroudCB = shroudCB.isChecked();
        Boolean is_spreaderCB = spreaderCB.isChecked();
        Boolean is_tackpinCB = tackpinCB.isChecked();
        Boolean is_whistleCB = whistleCB.isChecked();

        //Check for errors on all fields
        if(title.equals("") || details.equals("")){
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setMessage("Title or Details can't be empty.");
            alertDialog.show();
            return;
        }
        if(is_OtherCB == true && other.equals("") || is_OtherCB == false && !other.equals("")){
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setMessage("Checkbox 'Other' error!");
            alertDialog.show();
            return;
        }

        Pattern pattern = Pattern.compile("[0-9]{2}:[0-9]{2}:[0-9]{2}");
        if (!timespent.equals("") && !pattern.matcher(timespent).matches()) {
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setMessage("Time format is incorrect");
            alertDialog.show();
            return;
        }

        if(!partsused.equals("")){
            Pattern pattern1 = Pattern.compile("[0-9]+(,[0-9]+)*");
            if (!pattern1.matcher(partsused).matches()) {
                String[] parts = partsused.split(",");
                //TODO:check if each part is an actual part in database
            }

            //Fetch parts..

        }


        ArrayList<Boolean> checkboxes_checked = new ArrayList<>();
        checkboxes_checked.add(is_blockCB);
        checkboxes_checked.add(is_boomCB);
        checkboxes_checked.add(is_bumperCB);
        checkboxes_checked.add(is_bungeeCB);
        checkboxes_checked.add(is_cleaningCB);
        checkboxes_checked.add(is_cleatCB);
        checkboxes_checked.add(is_cunninghamCB);
        checkboxes_checked.add(is_fairleadCB);
        checkboxes_checked.add(is_fibreglassCB);
        checkboxes_checked.add(is_goosepinCB);
        checkboxes_checked.add(is_OtherCB);
        checkboxes_checked.add(is_gudgeonCB);
        checkboxes_checked.add(is_halyardCB);
        checkboxes_checked.add(is_hikingstrapCB);
        checkboxes_checked.add(is_mastballCB);
        checkboxes_checked.add(is_painterCB);
        checkboxes_checked.add(is_plugCB);
        checkboxes_checked.add(is_shroudCB);
        checkboxes_checked.add(is_spreaderCB);
        checkboxes_checked.add(is_tackpinCB);
        checkboxes_checked.add(is_whistleCB);
        if(!checkboxes_checked.contains(true)){
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setMessage("Please select issue/s!");
            alertDialog.show();
            return;
        }



        //Now,send this data to database

        ArrayList<String> task_and_creates_table_info = new ArrayList<>();
        task_and_creates_table_info.add(title); //tasknum and datecreated attributes will be taken care of by DatabasePostNewWorkOrder class
        task_and_creates_table_info.add(details);
        task_and_creates_table_info.add(Globals.currentSSN);
        task_and_creates_table_info.add(currentDate);

        ArrayList<String> problem_table_info = new ArrayList<>();
        if(is_reattachCB == true){problem_table_info.add("Reattach");}
        if(is_missingrequiresCB == true){problem_table_info.add("Missing/Requires");}
        if(is_replaceCB == true){problem_table_info.add("Replace");}
        if(is_repairCB == true){problem_table_info.add("Repair");}

        ArrayList<String> issue_table_info = new ArrayList<>();
        if(is_blockCB == true){issue_table_info.add("Block");}
        if(is_boomCB == true){issue_table_info.add("BoomVang");}
        if(is_bumperCB == true){issue_table_info.add("Bumper");}
        if(is_bungeeCB == true){issue_table_info.add("Bungee");}
        if(is_cleaningCB == true){issue_table_info.add("Cleaning");}
        if(is_cleatCB == true){issue_table_info.add("Cleat");}
        if(is_cunninghamCB == true){issue_table_info.add("Cunningham");}
        if(is_fairleadCB == true){issue_table_info.add("Fairlead");}
        if(is_fibreglassCB == true){issue_table_info.add("Fibreglass");}
        if(is_goosepinCB == true){issue_table_info.add("Goose Pin");}
        if(is_gudgeonCB == true){issue_table_info.add("Gudgeon");}
        if(is_halyardCB == true){issue_table_info.add("Halyard");}
        if(is_hikingstrapCB == true){issue_table_info.add("Hiking Strap");}
        if(is_mastballCB == true){issue_table_info.add("Mast Ball");}
        if(is_painterCB == true){issue_table_info.add("Painter");}
        if(is_plugCB == true){issue_table_info.add("Plug");}
        if(is_shroudCB == true){issue_table_info.add("Shroud");}
        if(is_spreaderCB == true){issue_table_info.add("Spreader");}
        if(is_tackpinCB == true){issue_table_info.add("Tack Pin");}
        if(is_whistleCB == true){issue_table_info.add("Whistle");}
        if(is_OtherCB == true){issue_table_info.add(other);}

        ArrayList<String> parts_used = new ArrayList<>();
        if(!partsused.equals("")){
            String[] pu;
            pu = partsused.split(",");
            parts_used = new ArrayList<>(Arrays.asList(pu));
        }

        ArrayList<String> boat_and_timespent = new ArrayList<>();
        boat_and_timespent.add(boat);
        boat_and_timespent.add(timespent);

        DatabaseCreatingNewTask databaseCreatingNewTask = new DatabaseCreatingNewTask(this);
        databaseCreatingNewTask.execute(task_and_creates_table_info,problem_table_info,issue_table_info,parts_used,
               boat_and_timespent);

    }

    @Override
    public void onBackPressed() {
        //Do nothing
    }

}
