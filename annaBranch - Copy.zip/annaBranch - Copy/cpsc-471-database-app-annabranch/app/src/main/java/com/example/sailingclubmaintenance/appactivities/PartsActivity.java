package com.example.sailingclubmaintenance.appactivities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sailingclubmaintenance.R;
import com.example.sailingclubmaintenance.Parts.DatabaseFetchParts;
import com.example.sailingclubmaintenance.Parts.NewPart;
import com.example.sailingclubmaintenance.Parts.Part;
import com.example.sailingclubmaintenance.Parts.PartsAdapter;
import com.example.sailingclubmaintenance.login.Globals;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class PartsActivity extends AppCompatActivity {

    //public static List<Part> partsList;
   public static RecyclerView recyclerView;

    public static List<Part> refreshParts(String result) {
        Globals.partsList = new ArrayList<>();
        try{
            JSONArray array = new JSONArray(result);

            for (int i = 0; i < array.length(); i++) {
                JSONObject part = array.getJSONObject(i);
                Globals.partsList.add(new Part(
                        part.getString("SerialNum"),
                        part.getString("Type"),
                        part.getString("P_Condition"),
                        part.getString("Man_Month"),
                        part.getString("Man_Year"),
                        part.getString("Pur_Date"),
                        part.getString("stockName")
                ));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return Globals.partsList;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parts);
        //TOOLBAR
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        String type = "getParts";
        DatabaseFetchParts dbFetchParts = new DatabaseFetchParts(this);
        dbFetchParts.execute(type);

        recyclerView = (RecyclerView) findViewById(R.id.parts_list);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //PartsAdapter adapter = new PartsAdapter(this, Globals.partsList);
        //recyclerView.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Set fab to create new part to add to list
                createNewPart();
            }
        });


    }


    //creates instance of new part activity
    private void createNewPart() {
        Intent intent = new Intent(getApplicationContext(), NewPart.class);
        startActivity(intent);

    }


}
