package com.example.sailingclubmaintenance.Parts;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sailingclubmaintenance.R;

import java.util.List;

public class PartsAdapter extends RecyclerView.Adapter<PartsAdapter.PartViewHolder> {
    private Context ctx;

    private List<Part> partList;

    public PartsAdapter(Context ctx, List<Part> partList){
        this.ctx = ctx;
        this.partList = partList;
    }


    @Override
    public PartsAdapter.PartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(ctx);
        View view = inflater.inflate(R.layout.part_info_layout, null);
        return new PartsAdapter.PartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PartsAdapter.PartViewHolder holder, int position) {
        Part part = partList.get(position);

        holder.textViewType.setText(part.getType());
        holder.textViewSerialNum.setText(part.getSerialNum());
        holder.textViewCondition.setText(part.getCondition());
        holder.textViewManDate.setText(part.getManDate());
        holder.textViewPurDate.setText(part.getPurDate());
        holder.VHstockName.setText(part.getStockName());

    }

    @Override
    public int getItemCount() {
        return partList.size();
    }

    class PartViewHolder extends RecyclerView.ViewHolder {

        TextView textViewType, textViewSerialNum, textViewCondition, textViewManDate, textViewPurDate, VHstockName;

        public PartViewHolder(View itemView) {
            super(itemView);

            textViewType = itemView.findViewById(R.id.textViewType);
            textViewSerialNum= itemView.findViewById(R.id.textViewSerialNum);
            textViewCondition = itemView.findViewById(R.id.textViewCondition);
            textViewManDate = itemView.findViewById(R.id.textViewManDate);
            textViewPurDate = itemView.findViewById(R.id.textViewPurDate);
            VHstockName = itemView.findViewById(R.id.VHstockName);

        }
    }

}
