package com.example.sailingclubmaintenance.Settings;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.sailingclubmaintenance.R;
import com.example.sailingclubmaintenance.login.Globals;

public class ChangePassword extends AppCompatActivity {

    EditText oldPass, newPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        oldPass = (EditText)findViewById(R.id.currentPass);
        newPass = (EditText)findViewById(R.id.newPass);

    }

    public void changePassword(View view) {
        String str_oldPass = oldPass.getText().toString();
        String str_newPass = newPass.getText().toString();

        String type = "changePass";

        DatabasePasswordChange dbPass = new DatabasePasswordChange(this);
        dbPass.execute(type, Globals.currentSSN, str_oldPass, str_newPass);

    }
}
