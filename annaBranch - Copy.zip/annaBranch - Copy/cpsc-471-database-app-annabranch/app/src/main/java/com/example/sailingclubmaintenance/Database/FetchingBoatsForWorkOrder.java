package com.example.sailingclubmaintenance.Database;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.sailingclubmaintenance.login.Globals;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * This class is used to populate the spinner in new work order form
 */
public class FetchingBoatsForWorkOrder extends AsyncTask<Spinner, Void, Map> {

    private Context context;
    private Map<String,String> boatANDName_Map = new HashMap<String,String>();
    private Spinner spinner;

    //Constructor
    public FetchingBoatsForWorkOrder(Context ctx) {
        context = ctx;
    }

    @Override
    protected Map doInBackground(Spinner... params) { //Spinner is the argument we give
            spinner = params[0]; //Which is spinner
            String yourIpV4 = Globals.yourIPV4;
            String all_boat_table = "get_all_boats.php";

            try {
                JSONArray jsonArray1 = retrieveData(yourIpV4, all_boat_table);

                //Loop to populate the boatANDName_Map map.
                for (int i = 0; i < jsonArray1.length(); i++) {
                    JSONObject jo = (JSONObject) jsonArray1.get(i);
                    boatANDName_Map.put((String)jo.get("SerialNum"),(String) jo.get("Name"));
                }

            }catch(Exception e){e.printStackTrace();}

            return boatANDName_Map;
    }


    /**
     * What to do with the data once we get it..
     * @param boatANDName_Map
     */
    @Override
    protected void onPostExecute(Map boatANDName_Map) {

        //Here we are basically adding boats to the spinner
        Map<String,String> map = boatANDName_Map;
        ArrayList<String> boats = new ArrayList<>();
        boats.add("None");

        for (Map.Entry<String,String> entry: map.entrySet()){
            String boat_serialnum_and_name = entry.getKey() + " - " + entry.getValue();
            boats.add(boat_serialnum_and_name);
        }

        String[] boatAndName_converted = boats.toArray(new String[boats.size()]);

        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                context, android.R.layout.simple_spinner_item, boatAndName_converted);
        spinnerArrayAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );

        spinner.setAdapter(spinnerArrayAdapter);

    }


    /**
     * This method retrieves data as JSON array from url.
     * @param yourIPV4
     * @param phpFileName
     * @return JSONArray
     * @throws IOException
     * @throws JSONException
     */
    public JSONArray retrieveData(String yourIPV4,String phpFileName) throws IOException, JSONException {
        String taskdata = "";

        //1.Create connection with url
        URL url = new URL("http://" + yourIPV4 + "/" + phpFileName);
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

        //2.Open channel of communication
        InputStream inputStream = httpURLConnection.getInputStream();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

        //3.Read line by line to get a string of data
        String line = "";
        while (line != null) {
            line = bufferedReader.readLine();
            taskdata = taskdata + line;
        }

        //4.Parse results, adding strings of data to ArrayList of ArrayLists
        JSONArray jsonArray = new JSONArray(taskdata);

        return jsonArray;
    }


}
