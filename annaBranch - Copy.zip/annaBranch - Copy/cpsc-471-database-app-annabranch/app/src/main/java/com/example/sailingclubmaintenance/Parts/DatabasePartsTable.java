package com.example.sailingclubmaintenance.Parts;

import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;

import com.example.sailingclubmaintenance.login.Globals;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;


/**
 * This class retrieves note table from database
 */
public class DatabasePartsTable extends AsyncTask<String,Void,String> {

    private Context context;
    private AlertDialog alertDialogNote;

    //Constructor
    public DatabasePartsTable(Context ctx) {
        context = ctx;
    }

    @Override
    protected String doInBackground(String... params) {
        String type = params[0]; //Type of query we want
        String yourIPV4 = Globals.yourIPV4;

        String newPart_url = "http://"+yourIPV4+"/part_new.php";
        String deletePart_url = "http://"+yourIPV4+"/part_delete.php";
      //  String updatePart_url = "http://"+yourIPV4+"/part_edit.php"; //not implemented

        if(type.equals("saveNewPart")){ //Check what type of query it is
            androidx.appcompat.app.AlertDialog.Builder ad = new androidx.appcompat.app.AlertDialog.Builder(context).setMessage("Adding new part...").setCancelable(false);
            ad.show();
            try {
                String SerialNum = params[1];
                String Type = params[2];
                String Condition = params[3];
                String Man_Month = params[4];
                String Man_Year = params[5];
                String Pur_Date = params[6];
                String stock_Name = params[7];
                URL url = new URL(newPart_url); //set url to which we will post this info
                HttpURLConnection httpURLConnection = (HttpURLConnection)    url.openConnection();
                httpURLConnection.setRequestMethod("POST"); //make sure we are posting
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
                //Write the following data..
                String post_data = URLEncoder.encode("SerialNum","UTF-8")+"="+URLEncoder.encode(SerialNum,"UTF-8")
                        +"&"+URLEncoder.encode("Type","UTF-8")+"="+URLEncoder.encode(Type,"UTF-8")
                        +"&"+URLEncoder.encode("Condition","UTF-8")+"="+URLEncoder.encode(Condition,"UTF-8")
                        +"&"+URLEncoder.encode("Man_Month","UTF-8")+"="+URLEncoder.encode(Man_Month,"UTF-8")
                        +"&"+URLEncoder.encode("Man_Year","UTF-8")+"="+URLEncoder.encode(Man_Year,"UTF-8")
                        +"&"+URLEncoder.encode("Pur_Date","UTF-8")+"="+URLEncoder.encode(Pur_Date,"UTF-8")
                        +"&"+URLEncoder.encode("stock_Name","UTF-8")+"="+URLEncoder.encode(stock_Name,"UTF-8");
                bufferedWriter.write(post_data);
                //Flush and close everything
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                //Now, we would like to recieve the result
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result =  "";
                String line="";
                while((line = bufferedReader.readLine()) !=null){ //reading the result line by line
                    result+=line;
                }
                //Log.d("myTag",result);
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }else if (type.equals("deletePart")){
            try {
                String SerialNum = params[1];
                URL url = new URL(deletePart_url); //set url to which we will post this info
                HttpURLConnection httpURLConnection = (HttpURLConnection)    url.openConnection();
                httpURLConnection.setRequestMethod("POST"); //make sure we are posting
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
                //Write the following data..
                String post_data = URLEncoder.encode("SerialNum","UTF-8")+"="+URLEncoder.encode(SerialNum,"UTF-8");
                bufferedWriter.write(post_data);
                //Flush and close everything
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                //Now, we would like to recieve the result
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result =  "";
                String line="";
                while((line = bufferedReader.readLine()) !=null){ //reading the result line by line
                    result+=line;
                }
                //Log.d("myTag",result);
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }else if (type.equals("updatePart")) { //NOT IMPLEMENTED

        }
        return null;
    }

    @Override
    protected void onPreExecute() {
        alertDialogNote = new AlertDialog.Builder(context).create();
        alertDialogNote.setTitle("Message");
    }

    @Override
    protected void onPostExecute(String result) {
        alertDialogNote.setMessage(result);
        alertDialogNote.show();
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }
}
